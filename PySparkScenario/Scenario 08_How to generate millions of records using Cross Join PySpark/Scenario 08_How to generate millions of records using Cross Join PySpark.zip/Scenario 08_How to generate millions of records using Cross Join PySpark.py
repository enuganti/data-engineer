# Databricks notebook source
# MAGIC %md
# MAGIC #### **Cross Join**
# MAGIC - A Cross Join in PySpark is a join operation that returns the **Cartesian product of two DataFrames**.
# MAGIC - In other words, it combines **every row** from the **left** DataFrame with **every row** from the **right** DataFrame, resulting in a large, unfiltered result.

# COMMAND ----------

# MAGIC %md
# MAGIC **Syntax**
# MAGIC
# MAGIC      df1.crossJoin(df2)
# MAGIC
# MAGIC      # Spark SQL Equivalent of Cross Join
# MAGIC      SELECT * FROM employees e
# MAGIC      CROSS JOIN departments d;

# COMMAND ----------

# MAGIC %md
# MAGIC #### **This Notebook Covers below topics:**
# MAGIC - How to cross join two dataframes?
# MAGIC - How to generate millions or records (PySpark)?
# MAGIC - How to generate millions of records (spark sql)?

# COMMAND ----------

# MAGIC %md
# MAGIC #### **1) How to cross join two dataframes?**

# COMMAND ----------

# DBTITLE 1,create sample dataframe
# Create DataFrames for Employees and Departments
data_employees = [(1, "Ravi", "ADF"), (2, "Ritesh", "ADB"), (3, "Ramesh", "Azure")]
data_departments = [(123, "HR", "A"), (124, "IT", "B"), (125, "Admin", "C")]

columns_employees = ["emp_id", "emp_name", "Technology"]
columns_departments = ["dept_id", "dept_name", "Block"]

df_employees = spark.createDataFrame(data_employees, columns_employees)
display(df_employees)

df_departments = spark.createDataFrame(data_departments, columns_departments)
display(df_departments)

# COMMAND ----------

# DBTITLE 1,cross join
# Perform Cross Join
df_cross_joined = df_employees.crossJoin(df_departments)

# Show the result
display(df_cross_joined)

# COMMAND ----------

# MAGIC %md
# MAGIC #### **2) How to generate millions of records (PySpark)?**

# COMMAND ----------

df_crs_join = spark.read.csv("/FileStore/tables/cross_join.csv", header=True, inferSchema=True)
display(df_crs_join)

# COMMAND ----------

# Save the DataFrame as a table
df_crs_join.write.mode("overwrite").saveAsTable("tbl_crs_joins")

# COMMAND ----------

df_range1 = spark.range(10000, 10010000)
print("Million Records:", df_range1.count())
display(df_range1)

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.types import IntegerType

# df_range2 = spark.range(10000, 10010000).withColumn("value", (f.col("id") % 100))
df_range2 = spark.range(10000, 10010000).withColumn("value", (f.col("id") % 100).cast(IntegerType()))
display(df_range2)

# COMMAND ----------

# DBTITLE 1,cross join with first record
# select only first record of "df_crs_join"
df_Sales_limit = df_crs_join.limit(1)
df_range = spark.range(10000, 10010000).withColumn("value", (f.col("id") % 100).cast(IntegerType()))

df_join_limit = df_Sales_limit.crossJoin(df_range)

print("Number of Records after Cross Join:", df_join_limit.count())
print("Number of distinct Records after Cross Join:", df_join_limit.distinct().count())
display(df_join_limit)

# COMMAND ----------

df_join_limit.select('Company_Name').distinct().show()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql.functions import col, when

df_join_limit = df_join_limit.withColumn('row_number', row_number().over(Window.orderBy('Company_Name')))
display(df_join_limit)

# COMMAND ----------

df_join_limit.select('row_number').distinct().count()

# COMMAND ----------

df_join_drop = df_join_limit.drop('Product_Id', 'Product_Version_Id')

crs_df = df_join_drop.withColumn('Product_Id', f.col('id'))\
                     .withColumn('Product_Version_Id', f.col('id'))\
                     .withColumn('End_Date', f.col('End_Date')+200)\
                     .withColumn('Updated_Date', f.col('Updated_Date')+600)\
                     .withColumn('Last_Date_UTC', f.col('Last_Date_UTC')+950)\
                     .withColumn('Cust_Value', f.col('Cust_Value')+10)\
                     .withColumn('Company_Name',
                                 when((col('row_number') >= 0) & (col('row_number') < 2000000), 'IBM')
                                 .when((col('row_number') >= 2000000) & (col('row_number') < 4000000), 'ACCENTURE')
                                 .when((col('row_number') >= 4000000) & (col('row_number') < 6000000), 'DELL')
                                 .when((col('row_number') >= 6000000) & (col('row_number') < 8000000), 'CAPGEMINI')
                                 .when((col('row_number') >= 8000000) & (col('row_number') < 10000000), 'GOOGLE')
                                 .otherwise(col('Company_Name')))\
                     .withColumn('Category',
                                 when((col('row_number') >= 0) & (col('row_number') < 2000000), 'STANDARD')
                                 .when((col('row_number') >= 2000000) & (col('row_number') < 4000000), 'MEDIUM')
                                 .when((col('row_number') >= 4000000) & (col('row_number') < 6000000), 'AVERAGE')
                                 .when((col('row_number') >= 6000000) & (col('row_number') < 8000000), 'HIGH')
                                 .when((col('row_number') >= 8000000) & (col('row_number') < 10000000), 'LOWEST')
                                 .otherwise(col('Category')))\
                    .withColumn('Location',
                                 when((col('row_number') >= 0) & (col('row_number') < 3000000), 'Bangalore')
                                 .when((col('row_number') >= 3000000) & (col('row_number') < 6000000), 'Chennai')
                                 .when((col('row_number') >= 6000000) & (col('row_number') < 9000000), 'Hyderabad')
                                 .otherwise(col('Location')))\
                    .withColumn('Cust_Type',
                                 when((col('row_number') >= 0) & (col('row_number') < 2500000), 'Gold')
                                 .when((col('row_number') >= 2500000) & (col('row_number') < 5000000), 'Silver')
                                 .when((col('row_number') >= 5000000) & (col('row_number') < 7500000), 'Bronze')
                                 .otherwise(col('Cust_Type')))\
                    .withColumn('Start_Date',
                                 when((col('row_number') >= 0) & (col('row_number') < 2000000), '13-Mar-22')
                                 .when((col('row_number') >= 2000000) & (col('row_number') < 4000000), '23-Apr-22')
                                 .when((col('row_number') >= 4000000) & (col('row_number') < 6000000), '03-Jun-23')
                                 .when((col('row_number') >= 6000000) & (col('row_number') < 8000000), '15-Nov-23')
                                 .when((col('row_number') >= 8000000) & (col('row_number') < 10000000), '30-Dec-23')
                                 .otherwise(col('Start_Date')))
display(crs_df)

# COMMAND ----------

print("Number of distinct Records after Cross Join:", crs_df.distinct().count())
display(crs_df.select('Company_Name').distinct())
display(crs_df.select('Category').distinct())
display(crs_df.select('Location').distinct())
display(crs_df.select('Cust_Type').distinct())
display(crs_df.select('Start_Date').distinct())

# COMMAND ----------

# DBTITLE 1,cross join with all records
# select all records of "df_crs_join"
df_Sales = df_crs_join
df_range = spark.range(10000, 10010000).withColumn("value", (f.col("id") % 100).cast(IntegerType()))

df_join = df_Sales.crossJoin(df_range)

display(df_join)
print("Number of Records after Cross Join:", df_join.count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### **3) How to generate millions of records (spark sql)?**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE products(
# MAGIC   id int,
# MAGIC   name STRING,
# MAGIC   productSize STRING
# MAGIC );
# MAGIC
# MAGIC INSERT INTO products
# MAGIC VALUES
# MAGIC (1, 'A', 'LOW'),
# MAGIC (2, 'B', 'LOW'),
# MAGIC (3, 'C', 'HIGH'),
# MAGIC (4, 'D', 'LOW'),
# MAGIC (5, 'E', 'LOW'),
# MAGIC (6, 'F', 'HIGH'),
# MAGIC (7, 'G', 'HIGH'),
# MAGIC (8, 'H', 'HIGH'),
# MAGIC (9, 'I', 'LOW'),
# MAGIC (10, 'J', 'LOW');
# MAGIC
# MAGIC SELECT * FROM products;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM tbl_crs_joins

# COMMAND ----------

# MAGIC %sql
# MAGIC -- disadvantages: 'id' is repeating
# MAGIC -- 'products' has 10 records and 'tbl_crs_joins' has 50 records. Total of 10*50=500 records
# MAGIC SELECT p.id, p.name, p.productSize, t.Product_Id FROM products p, tbl_crs_joins t

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 'products' has 10 records and 'tbl_crs_joins' has 50 records. Total of 10*50=500 records
# MAGIC SELECT row_number() over(order by p.id) as id, p.name, p.productSize, t.Product_Id FROM products p, tbl_crs_joins t

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 'products' has 10 records and 'tbl_crs_joins' has 50 records. Total of 10*50=500 records
# MAGIC SELECT row_number() over(order by p.id) as id, p.name, 
# MAGIC CASE
# MAGIC   WHEN row_number() over(order by p.id)%3=0 THEN 'Lower'
# MAGIC   WHEN row_number() over(order by p.id)%2=0 THEN 'Higher'
# MAGIC   ELSE 'Medium'
# MAGIC   END productSize,
# MAGIC t.Product_Id
# MAGIC FROM products p, tbl_crs_joins t

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 'products' has 10 records and 'tbl_crs_joins' has 50 records. Total of 10*50=500 records
# MAGIC SELECT row_number() over(order by p.id) as id, p.name, 
# MAGIC CASE
# MAGIC   WHEN row_number() over(order by p.id)%3=0 THEN 'Lower'
# MAGIC   WHEN row_number() over(order by p.id)%2=0 THEN 'Higher'
# MAGIC   ELSE 'Medium'
# MAGIC   END productSize,
# MAGIC t.*
# MAGIC FROM products p, tbl_crs_joins t

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 'products' has 10 records and 'tbl_crs_joins' has 50 records. Total of 10*50=500 records
# MAGIC SELECT row_number() over(order by p.id) as id, p.name, 
# MAGIC CASE
# MAGIC   WHEN row_number() over(order by p.id)%3=0 THEN 'Lower'
# MAGIC   WHEN row_number() over(order by p.id)%2=0 THEN 'Higher'
# MAGIC   ELSE 'Medium'
# MAGIC   END productSize,
# MAGIC row_number() over(order by t.Product_Id) as Product_Id, t.* EXCEPT(Product_Id)
# MAGIC FROM products p, tbl_crs_joins t
