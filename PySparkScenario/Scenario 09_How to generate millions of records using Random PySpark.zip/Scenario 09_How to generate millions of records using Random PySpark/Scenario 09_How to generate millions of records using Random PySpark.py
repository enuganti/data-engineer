# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC      import random
# MAGIC      import datetime
# MAGIC
# MAGIC - **random.randint** function generates **integer values**
# MAGIC
# MAGIC       random.randint(10000, 10010000),
# MAGIC       random.randint(0, 1),  # Random integer for IntegerType --> to generate 0's
# MAGIC
# MAGIC - **random.uniform** function generates **float values**
# MAGIC
# MAGIC       random.uniform(-44, 350),  # Random float for COLUMN 01 within the specified range
# MAGIC       random.uniform(-22, 8),    # Random float for COLUMN 02 DoubleType
# MAGIC       random.uniform(-44, 15),   # Random float for COLUMN 03 DoubleType
# MAGIC
# MAGIC - **random.choice** function generates **string values**
# MAGIC
# MAGIC       random.choice(["TRUE", "FALSE"]),
# MAGIC       random.choice(["Endur"]),
# MAGIC       random.choice([""]),
# MAGIC
# MAGIC       NEW_COLUMN = [row['COLUMN 01'] for row in df.select('COLUMN 01').distinct().collect()]
# MAGIC       random.choice(NEW_COLUMN),
# MAGIC
# MAGIC - **random.choice([True, False])** function generates **boolean values**
# MAGIC
# MAGIC - **LongType**
# MAGIC
# MAGIC       int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # Random long for LongType
# MAGIC       int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # Random long for LongType
# MAGIC
# MAGIC - **date**
# MAGIC
# MAGIC       # Find the minimum and maximum Deal_Start_Date
# MAGIC       min_date_start = deal.agg(f.min("Deal_Start_Date")).collect()[0][0]
# MAGIC       max_date_start = deal.agg(f.max("Deal_Start_Date")).collect()[0][0]
# MAGIC
# MAGIC       random.uniform(min_date_start, max_date_start)

# COMMAND ----------

# DBTITLE 1,sample dataset
df = spark.read.csv("/FileStore/tables/random_data-3.csv", header=True, inferSchema=True)
display(df)

# COMMAND ----------

# DBTITLE 1,change data type
from pyspark.sql.functions import col, to_date
from pyspark.sql.types import LongType

df = df.withColumn("Start_Date", (to_date(col('Start_Date'), 'd-MMM-yy')))\
       .withColumn("Start_Cust_Date", col('Start_Cust_Date').cast(LongType()))\
       .withColumn("End_Date", col('End_Date').cast(LongType()))\
       .withColumn("Updated_Date", col('Updated_Date').cast(LongType()))\
       .withColumn("Last_Date_UTC", col('Last_Date_UTC').cast(LongType()))\
       .withColumn("Base_Start_Date", (to_date(col('Base_Start_Date'), 'M/d/yyyy')))\
       .withColumn("Base_End_Date", (to_date(col('Base_End_Date'), 'yyyy-MM-dd')))\
       .withColumn("Base_Expiration_Date", (to_date(col('Base_Expiration_Date'), 'yyyy-MM-dd')))\
       .withColumn("Base_Last_Sales_Date", (to_date(col('Base_Last_Sales_Date'), 'yyyy-MM-dd')))

# COMMAND ----------

# DBTITLE 1,distinct values
display(df.select('Company_Name').distinct())
display(df.select('Category').distinct())
display(df.select('Cust_Type').distinct())
display(df.select('Exchange').distinct())
display(df.select('Location').distinct())
display(df.select('Cust_Category').distinct())
display(df.select('Index').distinct())

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, BooleanType, TimestampType, DateType
import random
import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Method 01**
# MAGIC
# MAGIC **inferSchema=True**
# MAGIC
# MAGIC **df.distinct()**

# COMMAND ----------

# DBTITLE 1,Find min & max values of int & date columns
# Find the minimum and maximum Cust_Value
min_value_custValue = df.agg(f.min("Cust_Value")).collect()[0][0]
max_value_custValue = df.agg(f.max("Cust_Value")).collect()[0][0]

# Find the minimum and maximum Start_Date
min_date_start = df.agg(f.min("Start_Date")).collect()[0][0]
max_date_start = df.agg(f.max("Start_Date")).collect()[0][0]

# Find the minimum and maximum Base_Start_Date
min_date_base_start = df.agg(f.min("Base_Start_Date")).collect()[0][0]
max_date_base_start = df.agg(f.max("Base_Start_Date")).collect()[0][0]

# Find the minimum and maximum Base_End_Date
min_date_base_end = df.agg(f.min("Base_End_Date")).collect()[0][0]
max_date_base_end = df.agg(f.max("Base_End_Date")).collect()[0][0]

# Find the minimum and maximum Base_Expiration_Date
min_date_base_exp = df.agg(f.min("Base_Expiration_Date")).collect()[0][0]
max_date_base_exp = df.agg(f.max("Base_Expiration_Date")).collect()[0][0]

# Find the minimum and maximum Base_Last_Sales_Date
min_date_base_last = df.agg(f.min("Base_Last_Sales_Date")).collect()[0][0]
max_date_base_last = df.agg(f.max("Base_Last_Sales_Date")).collect()[0][0]

# COMMAND ----------

df.select('Cust_Name').distinct().display()

# COMMAND ----------

df.select('Cust_Name').distinct().collect()

# COMMAND ----------

[row['Cust_Name'] for row in df.select('Cust_Name').distinct().collect()]

# COMMAND ----------

datetime.datetime.now()

# COMMAND ----------

datetime.timedelta(days=random.randint(0, 365))

# COMMAND ----------

(datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365)))

# COMMAND ----------

((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp())

# COMMAND ----------

int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp())

# COMMAND ----------

# DBTITLE 1,Generate 10 million rows using rand()
# Function to generate random data
def generate_random_data(num_rows):
    data = []
    Cust_Name_list = [row['Cust_Name'] for row in df.select('Cust_Name').distinct().collect()]

    for _ in range(num_rows):
        row = (
            random.choice(["Sony", "BP", "Philips", "BPL", "Reliance"]),
            random.randint(1000, 10001000),
            random.randint(1000, 10001000),
            random.choice(Cust_Name_list),
            random.choice(["Premium", "Lower", "Medium", "Upper", "Standard"]),
            random.uniform(min_date_start, max_date_start),
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            random.randint(min_value_custValue, max_value_custValue),
            random.choice(["Standard", "Premium", "Luxury"]),
            random.choice(["EURO", "INR", "DOLLOR", "SEK"]),
            random.choice(["SriLanka", "USA", "INDIA", "UK", "SWEDEN", "GERMANY"]),
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            random.choice(["TOI", "RTO", "SETTL", "ADB", "TRADING"]),
            random.choice([True, False]), # Boolean Type
            random.choice([0]), # integer column has all rows with "0"
            random.choice([1]), # integer column has all rows with "1"
            random.choice([""]), # column has empty values
            random.uniform(min_date_base_start, max_date_base_start),
            random.uniform(min_date_base_end, max_date_base_end),
            random.uniform(min_date_base_exp, max_date_base_exp),
            random.uniform(min_date_base_last, max_date_base_last)
        )
        data.append(row)
    return data

# Generate and process data in smaller batches
batch_size = 1000000
num_batches = 10
dfs = []

for _ in range(num_batches):
    random_data = generate_random_data(batch_size)
    batch_df = spark.createDataFrame(random_data, df.schema)
    dfs.append(batch_df)

# Union all the smaller DataFrames
final_df = dfs[0]
for df in dfs[1:]:
    final_df = final_df.union(df)

# Display the final DataFrame
display(final_df)

# COMMAND ----------

final_df.count()

# COMMAND ----------

# DBTITLE 1,create temp view
final_df.createOrReplaceTempView('final_df_random')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM final_df_random

# COMMAND ----------

# DBTITLE 1,write million records data to target
# Save the DataFrame as a CSV file
(final_df.write
    .format('csv')
    .mode('overwrite') # Use "overwrite" to overwrite existing data, or "append" to add to existing data
    .option("header", "true") # Include header in the CSV file
    .save("/FileStore/tables/Generate_Random_Data/million_random_data.csv")) # Define the file path where you want to save the CSV file

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Method 02**
# MAGIC
# MAGIC **Define Schema**
# MAGIC
# MAGIC **distinct values: Manual entry**

# COMMAND ----------

# DBTITLE 1,Generate 10 million rows using rand()
# Define the schema based on the input DataFrame
schema_def = StructType([
    StructField("Company_Name", StringType(), True),
    StructField("Product_Id", IntegerType(), True),
    StructField("Product_Version_Id", IntegerType(), True),
    StructField("Cust_Name", StringType(), True),
    StructField("Category", StringType(), True),    
    StructField("Start_Date", DateType(), True),
    StructField("Start_Cust_Date", LongType(), True),
    StructField("End_Date", LongType(), True),
    StructField("Updated_Date", LongType(), True),
    StructField("Cust_Value", IntegerType(), True),
    StructField("Cust_Type", StringType(), True),
    StructField("Exchange", StringType(), True),
    StructField("Location", StringType(), True),
    StructField("Last_Date_UTC", LongType(), True),
    StructField("Cust_Category", StringType(), True),
    StructField("Index", BooleanType(), True),
    StructField("impact1", IntegerType(), True),
    StructField("impact2", IntegerType(), True),
    StructField("impact3", StringType(), True),
    StructField("Base_Start_Date", DateType(), True),
    StructField("Base_End_Date", DateType(), True),
    StructField("Base_Expiration_Date", DateType(), True),
    StructField("Base_Last_Sales_Date", DateType(), True)
])

# Function to generate random data
def generate_random_data(num_rows):
    data = []
    Cust_Name_list = [row['Cust_Name'] for row in df.select('Cust_Name').distinct().collect()]

    for _ in range(num_rows):
        row = (
            random.choice(["Sony", "BP", "Philips", "BPL", "Reliance"]),
            random.randint(1000, 10001000),
            random.randint(1000, 10001000),
            random.choice(Cust_Name_list),
            random.choice(["Premium", "Lower", "Medium", "Upper", "Standard"]),
            random.uniform(min_date_start, max_date_start),
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            random.randint(min_value_custValue, max_value_custValue),
            random.choice(["Standard", "Premium", "Luxury"]),
            random.choice(["EURO", "INR", "DOLLOR", "SEK"]),
            random.choice(["SriLanka", "USA", "INDIA", "UK", "SWEDEN", "GERMANY"]),
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            random.choice(["TOI", "RTO", "SETTL", "ADB", "TRADING"]),
            random.choice([True, False]), # Boolean Type
            random.choice([0]), # integer column has all rows with "0"
            random.choice([1]), # integer column has all rows with "1"
            random.choice([""]), # column has empty values
            random.uniform(min_date_base_start, max_date_base_start),
            random.uniform(min_date_base_end, max_date_base_end),
            random.uniform(min_date_base_exp, max_date_base_exp),
            random.uniform(min_date_base_last, max_date_base_last)
        )
        data.append(row)
    return data

# Generate and process data in smaller batches
batch_size = 1000000
num_batches = 10
dfs = []

for _ in range(num_batches):
    random_data = generate_random_data(batch_size)
    batch_df = spark.createDataFrame(random_data, schema_def)
    dfs.append(batch_df)

# Union all the smaller DataFrames
final_df_01 = dfs[0]
for df in dfs[1:]:
    final_df_01 = final_df_01.union(df)

# Display the final DataFrame
display(final_df_01)

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Method 03**
# MAGIC
# MAGIC **inferSchema=True**
# MAGIC
# MAGIC **distinct values by collect()**

# COMMAND ----------

# DBTITLE 1,Generate 10 million rows using rand()
# Function to generate random data
def generate_random_data(num_rows):
    data = []
    Company_Name_list = [row['Company_Name'] for row in df.select('Company_Name').distinct().collect()]
    Cust_Name_list = [row['Cust_Name'] for row in df.select('Cust_Name').distinct().collect()]
    Category_list = [row['Category'] for row in df.select('Category').distinct().collect()]
    Cust_Type_list = [row['Cust_Type'] for row in df.select('Cust_Type').distinct().collect()]
    Exchange_list = [row['Exchange'] for row in df.select('Exchange').distinct().collect()]
    Location_list = [row['Location'] for row in df.select('Location').distinct().collect()]
    Cust_Category_list = [row['Cust_Category'] for row in df.select('Cust_Category').distinct().collect()]
    
    for _ in range(num_rows):
        row = (
            random.choice(Company_Name_list),
            random.randint(1000, 10001000),
            random.randint(1000, 10001000),
            random.choice(Cust_Name_list),
            random.choice(Category_list),
            random.uniform(min_date_start, max_date_start),  # Use timestamp for uniform
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            random.randint(1000, 10001000),  # Assuming min_value_custValue and max_value_custValue
            random.choice(Cust_Type_list),
            random.choice(Exchange_list),
            random.choice(Location_list),
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            random.choice(Cust_Category_list),
            random.choice([True, False]),  # Boolean Type
            random.choice([0]),  # integer column has all rows with "0"
            random.choice([1]),  # integer column has all rows with "1"
            random.choice([""]),  # column has empty values
            random.uniform(min_date_base_start, max_date_base_start),
            random.uniform(min_date_base_end, max_date_base_end),
            random.uniform(min_date_base_exp, max_date_base_exp),
            random.uniform(min_date_base_last, max_date_base_last)
        )
        data.append(row)
    return data

# Generate and process data in smaller batches
batch_size = 1000000
num_batches = 10
dfs = []

for _ in range(num_batches):
    random_data = generate_random_data(batch_size)
    batch_df = spark.createDataFrame(random_data, df.schema)
    dfs.append(batch_df)

# Union all the smaller DataFrames
final_df_02 = dfs[0]
for df in dfs[1:]:
    final_df_02 = final_df_02.union(df)

# Display the final DataFrame
display(final_df_02)

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Method 04**
# MAGIC
# MAGIC **inferSchema=True**
# MAGIC
# MAGIC **distinct values of Integer Columns: Manual entry**

# COMMAND ----------

# DBTITLE 1,Generate 10 million rows using rand()
import multiprocessing ,os
from threading import current_thread

# List of allowed Id values
id_values = [103, 104, 110, 111, 112, 113, 114, 115, 116, 117, 126, 128, 129, 131, 133]
 
# List of allowed Version_Id values
Version_Id_values = [103, 104, 110, 111, 112, 113, 114, 115, 116, 117, 126, 128, 129, 131, 133]
 
# List of allowed Subversion_Id values
Subversion_Id_values = [1, 2, 4, 5]
 
# List of allowed Base_Id values
Base_Id_values = [3, 4]
 
# List of allowed Base_Profile_Id values
Base_Profile_Id_values = [9, 8, 7]
 
# Function to generate random data
def generate_random_data(num_rows):
    data = []
    Cust_Name_list = [row['Cust_Name'] for row in df.select('Cust_Name').distinct().collect()]

    for _ in range(num_rows):
        row = (
            random.choice(["Sony", "BP", "Philips", "BPL", "Reliance"]),
            random.randint(1000, 10001000),
            random.randint(1000, 10001000),
            random.choice(Cust_Name_list),
            random.choice(["Premium", "Lower", "Medium", "Upper", "Standard"]),
            random.uniform(min_date_start, max_date_start),
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            random.randint(min_value_custValue, max_value_custValue),
            random.choice(["Standard", "Premium", "Luxury"]),
            random.choice(["EURO", "INR", "DOLLOR", "SEK"]),
            random.choice(["SriLanka", "USA", "INDIA", "UK", "SWEDEN", "GERMANY"]),
            int((datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))).timestamp()),  # LongType
            random.choice(["TOI", "RTO", "SETTL", "ADB", "TRADING"]),
            random.choice([True, False]), # Boolean Type
            random.choice([0]), # integer column has all rows with "0"
            random.choice([1]), # integer column has all rows with "1"
            random.choice([""]), # column has empty values
            random.uniform(min_date_base_start, max_date_base_start),
            random.uniform(min_date_base_end, max_date_base_end),
            random.uniform(min_date_base_exp, max_date_base_exp),
            random.uniform(min_date_base_last, max_date_base_last)
        )
        data.append(row)
    return data
 
# Generate and process data in smaller batches
batch_size = 1000000
num_batches = 10

dfs = []
final_df_03 = spark.createDataFrame([], df.schema)

for _ in range(num_batches):
    random_data = generate_random_data(batch_size)
    batch_df = spark.createDataFrame(random_data, df.schema)
    dfs.append(batch_df)
 
# for i in dfs:
#     print( i.count())
 
for df in dfs:
    final_df_03 = final_df_03.union(df)

# # Union all the smaller DataFrames
# final_df = dfs[0]
# def union_df(df):
#     pid = os.getpid()
#     threadName = current_thread().name
#     # print(f"starting process {pid}")
#     print(f"starting thread {threadName}")
#     final_df = final_df.union(df)
# print(len(dfs))
 
# for df in dfs:
#     final_df = final_df.union(df)
#     t1 = threading.Thread(target=union_df, args=(df,))
#     t1.start()
#     t1.join()
# for df in dfs[1:]:
# #     # final_df = final_df.union(df)
#     p1 = multiprocessing.Process(target=union_df, args=(df,))
#     p1.start()
#     p1.join()
   
# Display the final DataFrame
display(final_df)
print("final_count :: ", final_df_03.count())
