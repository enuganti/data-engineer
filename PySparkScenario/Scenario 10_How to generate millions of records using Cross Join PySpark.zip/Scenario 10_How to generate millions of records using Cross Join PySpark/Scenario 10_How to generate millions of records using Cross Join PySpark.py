# Databricks notebook source
# DBTITLE 1,import required functions
import pyspark.sql.functions as f
from pyspark.sql.types import IntegerType, LongType

# COMMAND ----------

# DBTITLE 1,Load dataset
product_df = spark.read.csv("/FileStore/tables/cross_join_million-1.csv", header=True, inferSchema=True)

print("Number of Records in dataset:", product_df.count())
print("Number of distinct Records in dataset:", product_df.distinct().count())

display(product_df)

# COMMAND ----------

# DBTITLE 1,Iteration 01, 02, 03
# select only first record of "product_df"
df_prod = product_df.limit(1)
df_range = spark.range(10000, 3010000).withColumn("value", (f.col("id") % 100).cast(IntegerType()))

df_join = df_prod.crossJoin(df_range).drop('Product_Id','Product_Version_Id','Product_Subversion_Id','Product_Base_Id','Product_Base_Profile_Id')

print("Number of Records after Cross Join:", df_join.count())
print("Number of distinct Records after Cross Join:", df_join.distinct().count())

display(df_join.limit(600))

# COMMAND ----------

# DBTITLE 1,Iteration 04
# select only first record of "product_df"
df_prod = product_df.limit(1)
df_range = spark.range(10000, 1010000).withColumn("value", (f.col("id") % 100).cast(IntegerType()))

df_join = df_prod.crossJoin(df_range).drop('Product_Id','Product_Version_Id','Product_Subversion_Id','Product_Base_Id','Product_Base_Profile_Id')

print("Number of Records after Cross Join:", df_join.count())
print("Number of distinct Records after Cross Join:", df_join.distinct().count())

display(df_join.limit(10))

# COMMAND ----------

# DBTITLE 1,Iteration 01, 04
from pyspark.sql.functions import when, rand, lit

product_df = df_join.withColumn('Product_Id', f.col('id'))\
                    .withColumn('Product_Version_Id', f.col('id'))\
                    .withColumn('Product_Subversion_Id', f.lit(0))\
                    .withColumn('Product_Base_Id', f.lit(0))\
                    .withColumn('Product_Base_Profile_Id', f.lit(0))\
                    .withColumn('Product_Type', when(rand() < 0.5, 'Automatic').otherwise('Mannual'))\
                    .withColumn('Product_Flag', when(rand() < 0.5, 'Yes').otherwise('No'))\
                    .withColumn("Source", when(rand() < 0.3, lit('RESTAPI'))
                                          .when(rand() < 0.3, lit('MongoDB'))
                                          .when(rand() < 0.3, lit('Salesforce'))
                                          .otherwise(lit('CosmosDB')))\
                    .withColumn("Category", when(rand() < 0.3, lit('STANDARD'))
                                            .when(rand() < 0.2, lit('MEDIUM'))
                                            .when(rand() < 0.2, lit('AVERAGE'))
                                            .when(rand() < 0.2, lit('HIGH'))
                                            .otherwise(lit('LOWEST')))\
                    .withColumn("Index", when(rand() < 0.5, 'True').otherwise('False'))\
                    .withColumn("Location", when(rand() < 0.3, lit('INDIA'))
                                            .when(rand() < 0.3, lit('UK'))
                                            .when(rand() < 0.3, lit('Russia'))
                                            .otherwise(lit('Japan')))\
                    .withColumn('Last_Date', when(rand() < 0.5, lit('1726127367000'))
                                             .otherwise(lit('1727413385000')))\
                    .withColumn('Start_Cust_Date', when(rand() < 0.12, lit('1714536000000'))
                                                   .when(rand() < 0.12, lit('1727755200000'))
                                                   .when(rand() < 0.12, lit('1711944000000'))
                                                   .when(rand() < 0.12, lit('1722484800000'))
                                                   .when(rand() < 0.12, lit('1709269200000'))
                                                   .when(rand() < 0.12, lit('1719806400000'))
                                                   .when(rand() < 0.12, lit('1730437200000'))
                                                   .otherwise(lit('1730073600000')))\
                    .withColumn('End_Date', when(rand() < 0.12, lit('1717214400000'))
                                            .when(rand() < 0.12, lit('1730437200000'))
                                            .when(rand() < 0.12, lit('1714536000000'))
                                            .when(rand() < 0.12, lit('1725163200000'))
                                            .when(rand() < 0.12, lit('1719806400000'))
                                            .when(rand() < 0.12, lit('1735707600000'))
                                            .when(rand() < 0.12, lit('1743480000000'))
                                            .when(rand() < 0.12, lit('1748728800000'))
                                            .when(rand() < 0.12, lit('1743307200000'))
                                            .otherwise(lit('1767243600000')))\
                    .withColumn("Start_Cust_Date", f.col("Start_Cust_Date").cast(LongType()))\
                    .withColumn("End_Date", f.col("End_Date").cast(LongType()))\
                    .withColumn("Last_Date", f.col("Last_Date").cast(LongType()))

display(product_df.limit(600))

# COMMAND ----------

# DBTITLE 1,Iteration 02
from pyspark.sql.functions import when, rand, lit

product_df = df_join.withColumn('Product_Id', f.col('id'))\
                    .withColumn('Product_Version_Id', f.col('id'))\
                    .withColumn('Product_Subversion_Id', f.lit(0))\
                    .withColumn('Product_Base_Id', f.lit(2))\
                    .withColumn('Product_Base_Profile_Id', f.lit(3))\
                    .withColumn('Product_Type', when(rand() < 0.4, lit('Automatic'))
                                                .when(rand() < 0.3, lit('Manual'))
                                                .otherwise('AI'))\
                    .withColumn('Product_Flag', when(rand() < 0.5, 'Yes').otherwise('No'))\
                    .withColumn("Source", when(rand() < 0.3, lit('RESTAPI'))
                                          .when(rand() < 0.3, lit('MongoDB'))
                                          .when(rand() < 0.3, lit('Salesforce'))
                                          .otherwise(lit('CosmosDB')))\
                    .withColumn("Category", when(rand() < 0.3, lit('STANDARD'))
                                            .when(rand() < 0.2, lit('MEDIUM'))
                                            .when(rand() < 0.2, lit('AVERAGE'))
                                            .when(rand() < 0.2, lit('HIGH'))
                                            .otherwise(lit('LOWEST')))\
                    .withColumn("Index", when(rand() < 0.5, 'True').otherwise('False'))\
                    .withColumn("Location", when(rand() < 0.3, lit('INDIA'))
                                            .when(rand() < 0.3, lit('UK'))
                                            .when(rand() < 0.3, lit('Russia'))
                                            .otherwise(lit('Japan')))\
                    .withColumn('Last_Date', when(rand() < 0.4, lit('1726127367000'))
                                             .when(rand() < 0.3, lit('1726527589000'))
                                             .otherwise(lit('1727413385000')))\
                    .withColumn('Start_Cust_Date', when(rand() < 0.2, lit('1714536000000'))
                                                   .when(rand() < 0.15, lit('1727755200000'))
                                                   .when(rand() < 0.15, lit('1711944000000'))
                                                   .when(rand() < 0.2, lit('1722484800000'))
                                                   .when(rand() < 0.15, lit('1709269200000'))
                                                   .otherwise(lit('1730073600000')))\
                    .withColumn('End_Date', when(rand() < 0.15, lit('1717214400000'))
                                            .when(rand() < 0.15, lit('1730437200000'))
                                            .when(rand() < 0.15, lit('1714536000000'))
                                            .when(rand() < 0.15, lit('1725163200000'))
                                            .when(rand() < 0.15, lit('1719806400000'))
                                            .when(rand() < 0.15, lit('1735707600000'))
                                            .otherwise(lit('1767243600000')))\
                    .withColumn("Start_Cust_Date", f.col("Start_Cust_Date").cast(LongType()))\
                    .withColumn("End_Date", f.col("End_Date").cast(LongType()))\
                    .withColumn("Last_Date", f.col("Last_Date").cast(LongType()))

display(product_df.limit(600))

# COMMAND ----------

# DBTITLE 1,Iteration 03
from pyspark.sql.functions import when, rand, lit

product_df = df_join.withColumn('Product_Id', f.col('id'))\
                    .withColumn('Product_Version_Id', f.col('id'))\
                    .withColumn('Product_Subversion_Id', f.lit(0))\
                    .withColumn('Product_Base_Id', f.lit(0))\
                    .withColumn('Product_Base_Profile_Id', f.lit(0))\
                    .withColumn('Product_Type', when(rand() < 0.5, 'Automatic').otherwise('Mannual'))\
                    .withColumn('Product_Flag', when(rand() < 0.5, 'Yes').otherwise('No'))\
                    .withColumn("Source", when(rand() < 0.3, lit('RESTAPI'))
                                          .when(rand() < 0.3, lit('MongoDB'))
                                          .when(rand() < 0.3, lit('Salesforce'))
                                          .otherwise(lit('CosmosDB')))\
                    .withColumn("Category", when(rand() < 0.3, lit('STANDARD'))
                                            .when(rand() < 0.2, lit('MEDIUM'))
                                            .when(rand() < 0.2, lit('AVERAGE'))
                                            .when(rand() < 0.2, lit('HIGH'))
                                            .otherwise(lit('LOWEST')))\
                    .withColumn("Index", when(rand() < 0.5, 'True').otherwise('False'))\
                    .withColumn("Location", when(rand() < 0.3, lit('INDIA'))
                                            .when(rand() < 0.3, lit('UK'))
                                            .when(rand() < 0.3, lit('Russia'))
                                            .otherwise(lit('Japan')))\
                    .withColumn('Last_Date', when(rand() < 0.5, lit('1726127367000'))
                                             .otherwise(lit('1727413385000')))\
                    .withColumn('Start_Cust_Date', when(rand() < 0.12, lit('1714536000000'))
                                                   .when(rand() < 0.12, lit('1727755200000'))
                                                   .when(rand() < 0.12, lit('1711944000000'))
                                                   .when(rand() < 0.12, lit('1722484800000'))
                                                   .when(rand() < 0.12, lit('1709269200000'))
                                                   .when(rand() < 0.12, lit('1719806400000'))
                                                   .when(rand() < 0.12, lit('1730437200000'))
                                                   .otherwise(lit('1730073600000')))\
                    .withColumn('End_Date', when(rand() < 0.12, lit('1717214400000'))
                                            .when(rand() < 0.12, lit('1730437200000'))
                                            .when(rand() < 0.12, lit('1714536000000'))
                                            .when(rand() < 0.12, lit('1725163200000'))
                                            .when(rand() < 0.12, lit('1719806400000'))
                                            .when(rand() < 0.12, lit('1735707600000'))
                                            .when(rand() < 0.12, lit('1743480000000'))
                                            .when(rand() < 0.12, lit('1748728800000'))
                                            .when(rand() < 0.12, lit('1743307200000'))
                                            .otherwise(lit('1767243600000')))\
                    .withColumn("Start_Cust_Date", f.col("Start_Cust_Date").cast(LongType()))\
                    .withColumn("End_Date", f.col("End_Date").cast(LongType()))\
                    .withColumn("Last_Date", f.col("Last_Date").cast(LongType()))

display(product_df.limit(600))

# COMMAND ----------

# DBTITLE 1,Iteration 01, 02, 03, 04
from pyspark.sql.functions import when, rand, col, lit, round
from pyspark.sql import functions as f

# Define the range
min_value = 25
max_value = 166

# Define the fixed integer values
fixed_values_cust = [25, 30, 40, 55, 70, 85, 100, 130, 150, 145, 160]

# Add a column with random fixed values
product_df = product_df\
    .withColumn('fixed_value', f.array([lit(x) for x in fixed_values_cust])[(rand() * len(fixed_values_cust)).cast('int')])

# Randomly assign values to 'Cust_Value' column
product_df = product_df.withColumn(
    'Cust_Value', 
    when(rand() < 0.4, col('fixed_value'))  # 40% fixed values
    .otherwise(round(rand() * (max_value - min_value) + min_value, 0))  # 60% random values
)

# Drop the temporary 'fixed_value' column
product_df = product_df.drop('fixed_value')
display(product_df.limit(700))

# COMMAND ----------

# DBTITLE 1,Iteration 01, 03, 04
# Define the range
min_value = -213.456
max_value = 433.768

# Define the fixed integer values
fixed_values_volume = [4, 5, 6, 10, 15, 125, 150, -22, -40]

# Add a column with random fixed values
product_df = product_df\
    .withColumn('fixed_value', f.array([lit(x) for x in fixed_values_volume])[(rand() * len(fixed_values_volume)).cast('int')])

# Randomly assign values to 'Gas_Volume_Hourly' column
product_df = product_df\
    .withColumn('Product_Volume', when(rand() < 0.4, col('fixed_value'))  # 30% fixed values
                                  .otherwise(round(rand() * (max_value - min_value) + min_value, 1))  # 70% random values
                                    )

# Drop the temporary 'fixed_value' column
product_df = product_df.drop('fixed_value')
display(product_df.limit(700))

# COMMAND ----------

# DBTITLE 1,Iteration 02, 03
# Define the range
min_value = -78.345
max_value = 67

# Define the fixed integer values
fixed_values_Pwr = [0.06, 0.576, 0.6, 1.8, 2, 2.4, 3, 3.6, 7.5, -0.6, -11]

# Add a column with random fixed values
product_df = product_df\
    .withColumn('fixed_value', f.array([lit(x) for x in fixed_values_Pwr])[(rand() * len(fixed_values_Pwr)).cast('int')])

# Randomly assign values to 'Gas_Volume_Hourly' column
product_df = product_df\
    .withColumn('Product_Volume_Start', when(rand() < 0.4, col('fixed_value'))  # 30% fixed values
                                        .otherwise(rand() * (max_value - min_value) + min_value)  # 70% random values
                                          )

# Drop the temporary 'fixed_value' column
product_df = product_df.drop('fixed_value')
display(product_df.limit(700))

# COMMAND ----------

# DBTITLE 1,Iteration 02, 04
# Define the range
min_value = -65.123
max_value = 41.89

# Define the fixed integer values
fixed_values_Gas = [4, 6, 10, 15, -22]

# Add a column with random fixed values
product_df = product_df\
    .withColumn('fixed_value', f.array([lit(x) for x in fixed_values_Gas])[(rand() * len(fixed_values_Gas)).cast('int')])

# Randomly assign values to 'Gas_Volume_Hourly' column
product_df = product_df\
    .withColumn('Product_Volume_End', when(rand() < 0.4, col('fixed_value'))  # 30% fixed values
                                      .otherwise(rand() * (max_value - min_value) + min_value)  # 70% random values
                                          )

# Drop the temporary 'fixed_value' column
product_df = product_df.drop('fixed_value')
display(product_df.limit(700))

# COMMAND ----------

product_df.write.mode('append').saveAsTable('TenMillionRecords')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM TenMillionRecords;

# COMMAND ----------

# DBTITLE 1,Iteration 01
# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM TenMillionRecords;

# COMMAND ----------

# DBTITLE 1,Iteration 02
# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM TenMillionRecords;

# COMMAND ----------

# DBTITLE 1,Iteration 03
# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM TenMillionRecords;

# COMMAND ----------

# DBTITLE 1,Iteration 04
# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM TenMillionRecords;
